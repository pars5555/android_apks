const vm = require('vm');
const os = require('os');
const fs = require('fs');
const WebSocket = require('ws');
const Buffer = require('buffer').Buffer;
const XMLHttpRequest = require("xhr2");
const standalone = os.platform() === 'android';


const convert = (extensionCommandStr, input) => {
    switch (extensionCommandStr) {
        case "chrome.debugger.sendCommand":
            return { id: input.targetId };
    }
};
const btoa = (text) => {
    const buffer = Buffer.from(text, 'binary');
    return buffer.toString('base64');
};
const atob = (base64) => {
    const buffer = Buffer.from(base64, 'base64');
    return buffer.toString('binary');
};

function redirectConsoleToFile(filePath) {
    fs.writeFile(filePath, '', (err) => {
        if (err) {
            console.error('Error emptying log file:', err);
        }
    });
    const originalConsole = {...console};

    console.debug = function (...args) {
        originalConsole.debug(...args);
        logToFile(filePath, 'DEBUG', args);
    };

    console.log = function (...args) {
        originalConsole.log(...args);
        logToFile(filePath, 'LOG', args);
    };

    console.warn = function (...args) {
        originalConsole.warn(...args);
        logToFile(filePath, 'WARN', args);
    };

    console.error = function (...args) {
        originalConsole.error(...args);
        logToFile(filePath, 'ERROR', args);
    };

    // Similarly, you can override other console methods like error, info, etc. if needed
}

function logToFile(filePath, level, messages) {
    const timestamp = new Date().toISOString();
    let logMessage = `${timestamp} [${level}]`;

    // Convert each argument to JSON if it's an object
    messages.forEach(arg => {
        if (typeof arg === 'object') {
            logMessage += ' ' + JSON.stringify(arg);
        } else {
            logMessage += ' ' + arg;
        }
    });

    logMessage += '\n';

    fs.appendFile(filePath, logMessage, (err) => {
        if (err) {
            console.error('Error writing to log file:', err);
        }
    });
}
if (!standalone){
    console.log = console.warn;
    console.debug = console.warn;
}
console.error('console.error testr');
console.warn('console.warn test');
console.log('console.log test');
const extensionRootDir = process.argv[2];
const device_uuid = process.argv[3];

let logDir = extensionRootDir + "/logs";
var logFilePath = logDir + "/" + device_uuid + ".log";
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir);
}


redirectConsoleToFile(logFilePath);

process.on('unhandledRejection', error => {
    console.error('bjr unhandledRejection: '+error.message+ ": " +  error.stack, error);
});


process.on('uncaughtException', error => {
    console.error('bjr uncaughtException: '+error.message+ ": " +  error.stack);
    process.exit(1);
});

// Catch fatal signals that might cause the app to crash
process.on('SIGTERM', () => {
    console.error('Received SIGTERM, shutting down gracefully...');
});

const manifestFile = extensionRootDir + '/manifest.json';
const manifestObject = JSON.parse(fs.readFileSync(manifestFile).toString());
const backgroundScriptFiles = manifestObject.background.scripts;
var lastCreatedTargetId = null;
const context = {
    running_in_nodejs: true,
    standalone: standalone,
    // SysBackground: null,
    console: console,
    btoa: btoa,
    atob: atob,
    onVmError: onVmError,
    json_decode: JSON.parse,
    URLSearchParams: URLSearchParams,
    XMLHttpRequest: XMLHttpRequest,
    fetch: fetch, //fetch is available in nodejs 17+, no need to install external libs
    // require: require,  never allow require in VM
    window: {setInterval: setInterval, setTimeout: setTimeout},
    setTimeout: (callback, delay, ...args) => {
        const wrappedCallback = () => {
            try {
                callback.apply(null, args);
            } catch (error) {
                // Handle the error by exposing it to the main context
                onVmError(error, 'setTimeout');
            }
        };
        return setTimeout(wrappedCallback, delay);
    }, setInterval: (callback, delay, ...args) => {
        const wrappedCallback = () => {
            try {
                callback.apply(null, args);
            } catch (error) {
                onVmError(error, 'setInterval');
            }
        };
        return setInterval(wrappedCallback, delay);
    },
    clearTimeout: clearTimeout,
    clearInterval: clearInterval,
    WebSocket: WebSocket,
    onWsOpen: onWsOpen,
    onWsClose: onWsClose,
    onWsError: onWsError,
    onExtensionRunnerReply: onExtensionRunnerReply,
    onContentJsMessageReceived: onContentJsMessageReceived,
    onCustomMessageReceived: onCustomMessageReceived,
    onContentJsReplyMessageReceived: onContentJsReplyMessageReceived,
    onExitCalled: onExitCalled,
    onCdpEvent: onCdpEvent,
    chrome: {
        'cookies': {
            set: function (cookie, callback) {
                //{"name":"aaa","value":"bbb","domain":"myhttpheader.com","path":"/","expires":-1,"httpOnly":false,"sameParty":false,"url":"https://myhttpheader.com"}

                context?.SysBackground?.__verbose && context.SysBackground.debug('cookies.set: ' + JSON.stringify(cookie));

                var params = {method: 'Storage.setCookies', params: {cookies: [cookie]}};
                if (callback) {
                    return runCdpCommand(params).then((res) => {
                        applyCallback(callback, res);
                    }).catch((err) => {
                        applyCallback(callback, JSON.parse(err.data)?.error.message);
                        onVmError(err, 'runCdpCommand Storage.setCookies');
                    });
                } else {
                    return runCdpCommand(params);
                }
            },
            //chrome.cookies.getAll({domain: "." + domain}, cbFunc);
            //todo write domain filter, currently it returns all cookies
            getAll: function (details, callback) {
                var params = {method: 'Storage.getCookies', params: {}};
                if (callback) {
                    return runCdpCommand(params).then((res) => {
                        applyCallback(callback, res);
                    }).catch((err) => {

                        applyCallback(callback, JSON.parse(err.data)?.error.message);
                        onVmError(err, 'runCdpCommand Storage.getCookies');
                    });
                } else {
                    return runCdpCommand(params);
                }
            }
        },
        'debugger': {
            attach: function (target, requiredVersion, callback) {
                applyCallback(callback);
            },
            onEvent: {
                onEventListeners: [],
                addListener: function (l) {
                    context.chrome.debugger.onEvent.onEventListeners.push(l);
                }
            },
            sendCommand: function (tab, method, params, callback) {
                console.debug('debugger.' + arguments.callee.name, tab, method, params);
                if (callback) {
                    runCdpCommand({method: method, params: params}, tab.tabId).then((res) => {
                        applyCallback(callback, res);
                    }).catch((err) => {
                        //{"action":"__sys_forward_to_nodejs","__sys_reply_id":"t9KEjILaaA","data":{},"error":true}
                        applyCallback(callback, JSON.parse(err.data)?.error?.message);
                        onVmError(err, 'runCdpCommand ' + method + "; " + JSON.stringify(params));
                    });
                } else {
                    return runCdpCommand({method: method, params: params}, tab.tabId);
                }
            }
        },
        tabs: {
            reload: function (tabId, reloadProperties, callback) {
                if (reloadProperties && reloadProperties.bypassCache) {
                    reloadProperties.ignoreCache = true;
                }
                if (callback) {
                    return runCdpCommand({method: 'Page.reload', params: reloadProperties}, tabId).then((res) => {
                        applyCallback(callback, res);
                    }).catch((err) => {
                        applyCallback(callback, JSON.parse(err.data)?.error?.message);
                        onVmError(err, 'runCdpCommand Page.reload' + "; " + JSON.stringify(reloadProperties));

                    });
                } else {
                    return runCdpCommand({method: 'Page.reload', params: reloadProperties}, tabId);
                }
            },
            executeScript: function (tabId, details, callback) {
                console.log('tabs.' + arguments.callee.name, arguments);
                var params = {method: 'Runtime.evaluate', params: {expression: details.code, replMode: true, allowUnsafeEvalBlockedByCSP: true}};
                if (callback) {
                    return runCdpCommand(params, tabId).then((res) => {
                        applyCallback(callback, res);
                    }).catch((err) => {

                        applyCallback(callback, JSON.parse(err.data)?.error?.message);
                        onVmError(err, 'runCdpCommand Runtime.evaluate' + "; " + JSON.stringify(params));

                    });
                } else {
                    return runCdpCommand(params, tabId);
                }

            },
            sendMessage: function (tabId, message, options, callback) {
                console.log('tabs.' + arguments.callee.name, arguments);
                sendMessageToContentJsPromise(message, {targetId: tabId}, true).then((res) => {
                    callback && callback(res);
                });
            },
            query: function (queryInfo, callback) {
                console.log('tabs.' + arguments.callee.name, arguments);
                callback(false);
            },
            remove: function (queryInfo, callback) {
                onVmError(new Error("tabs.update is not implemented yet"), 'tabs.update not implemented yet!');
                callback(false);
            },
            update: function (tabId, updateParams, callback) {
                onVmError(new Error("tabs.update is not implemented yet"), 'tabs.update not implemented yet!');
            },
            create: function (createProperties, callback) {
                //        chrome.tabs.create({url: 'about:blank'}, function (tab) {
                console.debug('tabs.' + arguments.callee.name, arguments);
                if (context.SysBackground.__sys_is_android_samsung_browser() || context.SysBackground.__sys_is_android_webview_browser()) {
                    return runCdpCommand({
                        method: 'getCurrentTargetId'
                    }).then((targetId) => {
                        return browsingDataRemove(targetId, context.chrome.browsingData.removeDataToRemove, createProperties).then((values) => {

                            return targetId;
                        }).catch((error) => {
                            onVmError(error, 'browsingDataRemove');
                            return targetId;
                        });
                    }).then((targetId) => {
                        if (context.SysBackground.__sys_is_android_webview_browser() )  {
                            return runCdpCommand({method: 'Page.navigate', params: {url: 'file:///data/local/tmp/rba_first_page.html'}}, targetId).then(()=>{return targetId;});
                        }
                        return targetId;
                    }).then((targetId) => {
                        console.log('samsung getCurrentTargetId: ' + targetId);
                        applyCallback(callback, {id: targetId});
                    }).catch((err) => {
                        onVmError(err, 'tabs.create->getCurrentTargetId');
                    });
                } else {
                    runCdpCommand({method: 'Target.createTarget', params: {url: createProperties.url}}).then((res) => {
                        return browsingDataRemove(res.targetId, context.chrome.browsingData.removeDataToRemove, createProperties).then((values) => {
                            return res;
                        }).catch((error) => {
                            onVmError(error, 'Target.createTarget');
                            return res;
                        });
                    }).then((res) => {
                        lastCreatedTargetId = res.targetId;
                        applyCallback(callback, convert("chrome.debugger.sendCommand", res));
                    }).catch((err) => {
                        if (context.SysBackground.__sys_is_android_opera_browser()) {
                            var tabCreationEventMillis = 10000;
                            var startTime = performance.now();
                            Promise.race([new Promise((resolve) => {
                                const checkTid = setInterval(() => {
                                    if (lastCreatedTargetId !== null) {
                                        clearInterval(checkTid);
                                        resolve(lastCreatedTargetId);
                                    }
                                }, 50);
                            }),
                                new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout for Target.targetCreated event: " + tabCreationEventMillis)), tabCreationEventMillis))]).then((tid) => {
                                var endTime = performance.now();
                                context.SysBackground.debug(`Target.targetCreated event received for opera browser in ${(endTime - startTime).toFixed(2)} ms`);

                                return browsingDataRemove(lastCreatedTargetId, context.chrome.browsingData.removeDataToRemove, createProperties).then((values) => {
                                    applyCallback(callback, convert("chrome.debugger.sendCommand", {targetId: lastCreatedTargetId}));
                                }).catch((error) => {
                                    applyCallback(callback, convert("chrome.debugger.sendCommand", {targetId: lastCreatedTargetId}));
                                    onVmError(error, 'browsingDataRemove');
                                });

                            }).catch((err) => {
                                onVmError(err, 'runCdpCommand Target.createTarget');
                            });
                        } else {
                            onVmError(err, 'runCdpCommand Target.createTarget');
                        }
                    });
                }


            },
            onUpdated: {
                addListener: function (callback) {
                    console.log('tabs.' + arguments.callee.name, arguments);

                }
            },
            onRemoved: {
                addListener: function (callback) {
                    console.log('tabs.' + arguments.callee.name, arguments);
                }
            },
            captureVisibleTab: function (windowId, options, callback) {
                if (lastCreatedTargetId) {
                    context.chrome.debugger.sendCommand({tabId: lastCreatedTargetId}, 'Page.captureScreenshot', options, function (imageBase64) {
                        if (imageBase64.data) {
                            applyCallback(callback, imageBase64.data);
                        } else {
                            applyCallback(callback, false);
                        }
                    });
                } else {
                    applyCallback(callback, false);
                }
            }
        },
        runtime: {
            onMessage: {
                onMessageListeners: [],
                addListener: function (l) {
                    context.chrome.runtime.onMessage.onMessageListeners.push(l);
                    console.log('runtime.onMessage.' + arguments.callee.name, arguments);
                }
            }

        },
        windows: {
            getCurrent: function (queryOptions, callback) {
                applyCallback(callback, false);
                console.log('windows.' + arguments.callee.name, arguments);

            }
        },
        browserAction: {
            onClicked: {
                addListener: function () {
                    console.log('browserAction.onClicked.' + arguments.callee.name, arguments);
                }

            }
        },
        proxy: {
            settings: {
                set: function (queryOptions, callback) {
                    applyCallback(callback, false);


                },
                clear: function (queryOptions, callback) {
                    applyCallback(callback, false);

                    console.log('proxy.settings.' + arguments.callee.name, arguments);

                }
            }
        },
        privacy: {
            network: {
                webRTCIPHandlingPolicy: {
                    set: function (queryOptions) {
                        console.log('privacy.network.webRTCIPHandlingPolicy.' + arguments.callee.name, arguments);
                        context.SysBackground.error('deprecated privacy.network.webRTCIPHandlingPolicy');
                    }
                }
            }
        },
        browsingData: {
            removeOptions: {},
            remove: function (options, dataToRemove, callback) {
                context.chrome.browsingData.removeOptions = options;
                context.chrome.browsingData.removeDataToRemove = dataToRemove;
                applyCallback(callback, true);
            }
        },
        webRequest: {
            onAuthRequiredListeners: [],

            onAuthRequired: {
                addListener: function (callback, filter, opt_extraInfoSpec) {
                    console.debug('deprecated webRequest.onAuthRequired.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);
                    context.chrome.webRequest.onAuthRequiredListeners.push({callback:callback, filter:filter, opt_extraInfoSpec:opt_extraInfoSpec});

                }
            },
            onErrorOccurred: {
                addListener: function (callback, filter, extraInfoSpec) {
                    console.debug('deprecated webRequest.onErrorOccurred.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);


                }
            },
            onBeforeRequest: {
                addListener: function (callback, filter, opt_extraInfoSpec) {
                    console.debug('deprecated webRequest.onBeforeRequest.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);
                }
            },
            onSendHeaders: {
                addListener: function (callback, filter, opt_extraInfoSpec) {
                    console.debug('deprecated webRequest.onSendHeaders.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);
                }
            },
            onHeadersReceived: {
                addListener: function (callback, filter, opt_extraInfoSpec) {
                    console.debug('deprecated webRequest.onHeadersReceived.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);
                },
                removeListener: function (l) {
                    console.debug('deprecated webRequest.removeListener.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);
                }
            },
            onBeforeSendHeaders: {
                addListener: function (callback, filter, opt_extraInfoSpec) {
                    console.debug('deprecated webRequest.onBeforeSendHeaders.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);
                }
            },
            onBeforeRedirect: {
                addListener: function (callback, filter, opt_extraInfoSpec) {
                    console.debug('deprecated webRequest.onBeforeRedirect.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);
                },
                removeListener: function (l) {
                    console.debug('deprecated webRequest.onBeforeRedirect.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);
                }
            },
            onCompleted: {
                addListener: function (callback, filter, opt_extraInfoSpec) {
                    console.debug('deprecated webRequest.onCompleted.' + arguments.callee.name + " please use SysBackground corresponding function", arguments);

                }
            }
        }

    }
};

function applyCallback(callback, ...args) {
    try {
        callback && callback.apply(null, args);
    } catch (error) {
        onVmError(error, 'applyCallback');
    }
}

function onWsOpen(params) {
    console.debug('BackgroundJsRunner onWsOpen');
}
function onWsClose(e) {
    console.debug('BackgroundJsRunner onWsClose', e);
    process.exit(1);
}
function onWsError(e) {
    console.debug('BackgroundJsRunner onWsError', e);
    process.exit(1);

}

function camelToSnake(str) {
    return str.replace(/([A-Z])/g, '_$1').toLowerCase();
}

function convertKeysToSnakeCase(obj) {
    const newObj = {};
    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            const newKey = camelToSnake(key);
            newObj[newKey] = obj[key];
        }
    }
    return newObj;
}
function browsingDataRemove(targetId, dataToRemove, createProperties) {
    console.debug('browsingDataRemove: ' + JSON.stringify([targetId, dataToRemove]));
    if (!dataToRemove) {
        return Promise.resolve(true);
    }
//todo apply commands one by one next to each other, and if one of then not resolved or error then report
    const promises = [];
    const TIMEOUT = 2000; // 2 seconds timeout for all commands

    const withTimeout = (label, promise, timeout) => {
        console.debug(`Starting ${label}`);
        let timeoutId;

        return new Promise((resolve) => {
            timeoutId = setTimeout(() => {
                console.debug(`Timeout ${label} after ${timeout}ms`);
                resolve({ timeout: true, command: label });
            }, timeout);

            promise
                .then((res) => {
                    clearTimeout(timeoutId);
                    console.debug(`Resolved ${label}`);
                    resolve(res);
                })
                .catch((err) => {
                    clearTimeout(timeoutId);
                    console.debug(`Rejected ${label} with error: ${err.message}`);
                    resolve({ error: err.message, command: label });
                });
        });
    };

    if (dataToRemove.cookies) {
        if (!context.SysBackground.__sys_is_android_opera_browser() && !context.SysBackground.__sys_is_android_webview_browser()) {
            promises.push(
                withTimeout(
                    'Storage.clearCookies',
                    runCdpCommand({ method: 'Storage.clearCookies' }),
                    TIMEOUT
                )
            );
        }

        promises.push(
            withTimeout(
                'Network.clearBrowserCookies',
                runCdpCommand({ method: 'Network.clearBrowserCookies' }, targetId),
                TIMEOUT
            )
        );
    }

    if (dataToRemove.history) {
        promises.push(
            withTimeout(
                'Page.resetNavigationHistory',
                runCdpCommand({ method: 'Page.resetNavigationHistory' }, targetId),
                TIMEOUT
            )
        );
    }

    promises.push(
        withTimeout(
            'Storage.getTrustTokens',
            runCdpCommand({ method: 'Storage.getTrustTokens' }, targetId).then((res) => {
                console.debug("Storage.getTrustTokens1: " + JSON.stringify(res));

                let ps = [];
                if (res.tokens && res.tokens.length > 0) {
                    for (let t of res.tokens) {
                        console.debug("Starting Storage.clearTrustTokens for " + t.issuerOrigin);
                        ps.push(
                            withTimeout(
                                `Storage.clearTrustTokens (${t.issuerOrigin})`,
                                runCdpCommand(
                                    { method: 'Storage.clearTrustTokens', params: { issuerOrigin: t.issuerOrigin } },
                                    targetId
                                ),
                                TIMEOUT
                            )
                        );
                    }
                }
                return Promise.all(ps);
            }),
            TIMEOUT
        )
    );

    if (dataToRemove.indexedDB) {
        dataToRemove.indexeddb = dataToRemove.indexedDB;
        delete dataToRemove.indexedDB;
    }

    if (dataToRemove.webSQL) {
        dataToRemove.websql = dataToRemove.webSQL;
        delete dataToRemove.webSQL;
    }

    const mmap = convertKeysToSnakeCase(dataToRemove);
    mmap.shared_storage = true;
    mmap.storage_buckets = true;
    mmap.interest_groups = true;
    mmap.shader_cache = true;
    mmap.other = true;
    delete mmap.passwords;

    const enableKeys = Object.keys(mmap).filter((key) => typeof mmap[key] !== 'undefined' && mmap[key]);

    if (enableKeys.length > 0) {
        const pp = { origin: "*", storageTypes: enableKeys.join(',') };

        promises.push(
            withTimeout(
                'Storage.clearDataForOrigin (global)',
                runCdpCommand({ method: 'Storage.clearDataForOrigin', params: pp }, targetId),
                TIMEOUT
            )
        );

        if (createProperties.next_url) {
            const parsedUrl = new URL(createProperties.next_url);
            if (parsedUrl.origin) {
                const ppNext = { origin: parsedUrl.origin, storageTypes: enableKeys.join(',') };
                promises.push(
                    withTimeout(
                        'Storage.clearDataForOrigin (next_url)',
                        runCdpCommand({ method: 'Storage.clearDataForOrigin', params: ppNext }, targetId),
                        TIMEOUT
                    )
                );
            }
        }
    }

    return Promise.allSettled(promises).then((results) => {
        const finalResult = {
            success: [],
            errors: []
        };

        results.forEach((result, index) => {
            if (result.status === 'fulfilled') {
                finalResult.success.push({ index: index + 1, value: result.value });
            } else if (result.status === 'rejected') {
                finalResult.errors.push({ index: index + 1, reason: result.reason });
            }
        });

        context?.SysBackground?.__verbose &&
        context.SysBackground.debug('browsingDataRemoved: ' + JSON.stringify(finalResult));

        if (finalResult.errors.length > 0) {
            context?.SysBackground?.__verbose &&
            context.SysBackground.error('browsingDataRemoved errors: ' + JSON.stringify(finalResult.errors));
        }

        return finalResult;
    });
}



var wsPromises = {};
function runCdpCommand(data, targetId) {
    //{action: '__sys_forward_to_cdp_runner',                           data: {method: 'Target.createTarget', params: {url: createProperties.url}}}
    //{"action":"__sys_forward_to_cdp_runner","target":{"targetId":"8"},"data":{"method":"Page.navigate","params":{"url":"https://balance.vanillagift.com/"}}}
    return new Promise((resolutionFunc, rejectionFunc) => {
        var __sys_reply_id = context.SysBackground.generateHash(10);
        wsPromises[__sys_reply_id] = {resolve: resolutionFunc, reject: rejectionFunc};
        var params = {action: '__sys_forward_to_cdp_runner', __sys_reply_id: __sys_reply_id, data: data};
        if (typeof targetId !== 'undefined') {
            params.target = {targetId: targetId};
        }
        context.SysBackground.__sys_ws_send_object_as_json_message(params, 0, false);
    });
}


function onContentJsReplyMessageReceived(payload, executionContextId, target, frameId, __sysb_reply_id) {
    console.log('onContentJsReplyMessageReceived', JSON.stringify(payload).substring(0, 100), executionContextId, target, frameId, __sysb_reply_id);
    for (var l of context.chrome.runtime.onMessage.onMessageListeners) {
        try {
            l(payload, {frameId: frameId, tab: {id: target.targetId}}, function (responsePayload) {
                wsPromises[__sysb_reply_id] && wsPromises[__sysb_reply_id].resolve(responsePayload);
            });
        } catch (error) {
            onVmError(error, 'onContentJsReplyMessageReceived');
        }

    }
}

function onCustomMessageReceived(payload) {
//onCustomMessageReceived:  { action: 'profile_destroy' }
    console.log('onCustomMessageReceived: ', payload);
    switch (payload.action) {
        case "profile_destroy":
            process.exit(1);
            break;
        default:
            console.error('unknown onCustomMessageReceived action: ', payload.action);
            break;
    }
}

function onContentJsMessageReceived(payload, executionContextId, target, frameId, __sysc_reply_id) {
    //console.log('onContentJsMessageReceived', payload, executionContextId, target, __sysc_reply_id);
    for (var l of context.chrome.runtime.onMessage.onMessageListeners) {
        try {
            l(payload, {frameId: frameId, tab: {id: target.targetId}}, function (responsePayload) {
                sendReplyToContentJsMessage(target, executionContextId, responsePayload, __sysc_reply_id);
            });
        } catch (error) {
            onVmError(error, 'onContentJsMessageReceived');
        }
    }
}

function sendReplyToContentJsMessage(target, executionContextId, payload, __sysc_reply_id) {
    runCdpCommand({
        method: 'Runtime.callFunctionOn',
        params: {functionDeclaration: 'onBackgroundReplyMessageReceived', 'arguments': [{value: payload}, {value: __sysc_reply_id}], executionContextId: executionContextId}
    }, target.targetId).then((res) => {
    }).catch((err) => {
        //context.SysBackground && context.SysBackground.error("aaaaaaaaaaa" + JSON.stringify(error));
        if (err?.data?.error?.code === -32000) {
            console.error("sendReplyToContentJsMessage, " + err.data.error.message + ":" + executionContextId);
        } else if (JSON.parse(err?.data??{})?.error?.code === -32000) {
            console.error("sendReplyToContentJsMessage, " + JSON.parse(err.data)?.error?.message + ":" + executionContextId);
        } else {
            onVmError(err, 'runCdpCommand Runtime.callFunctionOn');
        }
    });
}

function sendMessageToContentJsPromise(payload, target, toAllFrames) {
    return new Promise((resolutionFunc, rejectionFunc) => {
        runCdpCommand({
            method: 'getTargetIsolatedExecutionContextIds',
            method_args: [{targetId: target.targetId}]
        }).then((executionContextIds) => {
            var promises = [];
            for (var cId of executionContextIds) {
                var __sysb_reply_id = context.SysBackground.generateHash(10);
                wsPromises[__sysb_reply_id] = {resolve: resolutionFunc, reject: rejectionFunc};
                var promise = runCdpCommand({
                    method: 'Runtime.callFunctionOn',
                    params: {functionDeclaration: 'onBackgroundJsMessageReceived', 'arguments': [{value: payload}, {value: target}, {value: __sysb_reply_id}], executionContextId: cId}}, target.targetId);
                if (toAllFrames === false) {
                    break;
                }
                promises.push(promise);
            }
            Promise.all(promises).then((values) => {
                if (values.length === 1) {
                    resolutionFunc(values[0]);
                } else {
                    resolutionFunc(values);
                }
            }).catch((err) => {
                if (err?.data?.error?.code === -32000) {
                    console.error("sendReplyToContentJsMessage, " + err.data.error.message);
                } else if (JSON.parse(err?.data??{})?.error?.code === -32000) {
                    console.error("sendReplyToContentJsMessage, " + JSON.parse(err.data)?.error?.message);
                } else {
                    onVmError(err, 'runCdpCommand Runtime.callFunctionOn Promise.all');
                }

            });
        }).catch((error) => {
            onVmError(error, 'runCdpCommand getTargetIsolatedExecutionContextIds');
        });
    });
}

function onExtensionRunnerReply(obj) {
    if (typeof wsPromises[obj.__sys_reply_id] !== 'undefined') {
        if (typeof obj.error === 'undefined') {
            var res = standalone ? obj.data.result : obj.data.data.result;
            wsPromises[obj.__sys_reply_id].resolve(res);
        } else {
            console.log('onExtensionRunnerReply', obj);
            wsPromises[obj.__sys_reply_id].reject(obj);
        }
    }
}

function onCdpEvent(params, target, event) {
    //context.chrome.webRequest.onAuthRequiredListeners
    if (event === 'Fetch.authRequired') {

        var parsedUrl = new URL(params.authChallenge.origin);
        let details = {
            requestId: params.requestId,
            challenger: {host:parsedUrl.hostname, port:parsedUrl.port},
            frameId: params.frameId,
            frameType: params.resourceType,
            isProxy: params.authChallenge.source === 'Proxy',
            method: params.request.method,
            realm: params.authChallenge.realm,
            scheme: params.authChallenge.scheme,
            type: params.resourceType,
            url: params.request.url
        };


        for (l of context.chrome.webRequest.onAuthRequiredListeners)    {
            var requestId = params.requestId;
            l.callback(details, function(obj){
                //obj.authCredentials = {"username":"best","password":"proxy"}
                var params = {method: 'Fetch.continueWithAuth', params: {requestId: requestId, authChallengeResponse: {response:'ProvideCredentials', username:obj.authCredentials.username, password:obj.authCredentials.password}}};
                runCdpCommand(params, target.targetId);
            });
        }

    }
    if (event === 'Target.targetCreated' && params.targetInfo.type === 'page') {
        //@todo for samsung/opera browser it should wait until this event receive, then get current target and continue.
        context?.SysBackground?.__verbose && context.SysBackground.warn(JSON.stringify([params, target, event]));
        if (context.SysBackground.__sys_is_android_samsung_browser()) {

        } else if (context.SysBackground.__sys_is_android_opera_browser()) {
            //opera actually create a target but returns {"id":1,"error":{"code":-32000,"message":"Not supported"}}, so we should get targetid from this event
            lastCreatedTargetId = params.targetInfo.targetId;
        } else if (context.SysBackground.__sys_is_android_webview_browser()) {
            //this is first/default target for webview, and there will not create another target anymore, so we will use autoAttach:true to stop next targets creation and destroy them using <attachedToTarget> event
            lastCreatedTargetId = params.targetInfo.targetId;
        }
    }


    for (var l of context.chrome.debugger.onEvent.onEventListeners) {
        if (target) {
            target.tabId = target.targetId;
        }
        l(target, event, params);
    }
}

vm.createContext(context); // Contextify the object.

backgroundScriptFiles.forEach((fileRelativePath, index) => {
    var file = extensionRootDir + "/" + fileRelativePath;
    console.log(file);
    if (!fs.existsSync(file)) {
        return;
    }

    var code = fs.readFileSync(file).toString();
    !index && (code += '(' + function () {
        /*SysBackground.__sys_start_debugger = function (tabId, onAttached) {
         onAttached && onAttached(tabId);
         }*/
        SysBackground.__openExtensionsTab = function (callback) {
            console.warn('__openExtensionsTab no need in cdp');
            callback && callback();
        };

        SysBackground.__init();
    } + ")();");

    try {
        vm.runInContext(code, context);
    } catch (error) {
        onVmError(error, 'backgroundScriptFiles');
    }

});

function onVmError(error, from) {
    context?.SysBackground?.error(JSON.stringify([from, JSON.stringify(error.toString()), error?.stack, JSON.stringify(error)]));
    console.error(error,from );
}

function onExitCalled(code, message) {
    context?.SysBackground.error('onExitCalled: ' + code + " - " + JSON.stringify(message));
//    runCdpCommand({
//        method: 'closeAllTabsUsingCdpGetRequestAndExit'
//    }).then(() => {
//        process.exit(1);
//    });
}

