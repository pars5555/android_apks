const vm = require('vm');
const fs = require('fs');
const WebSocket = require('ws');
const Buffer = require('buffer').Buffer;
const XMLHttpRequest = require("xhr2");


const btoa = (text) => {
    const buffer = Buffer.from(text, 'binary');
    return buffer.toString('base64');
};
const atob = (base64) => {
    const buffer = Buffer.from(base64, 'base64');
    return buffer.toString('binary');
};

function redirectConsoleToFile(filePath) {
    fs.writeFile(filePath, '', (err) => {
        if (err) {
            console.error('Error emptying log file:', err);
        }
    });
    const originalConsole = {...console};

    console.debug = function (...args) {
        originalConsole.debug(...args);
        logToFile(filePath, 'DEBUG', args);
    };

    console.log = function (...args) {
        originalConsole.log(...args);
        logToFile(filePath, 'LOG', args);
    };

    console.warn = function (...args) {
        originalConsole.warn(...args);
        logToFile(filePath, 'WARN', args);
    };

    console.error = function (...args) {
        originalConsole.error(...args);
        logToFile(filePath, 'ERROR', args);
    };

    // Similarly, you can override other console methods like error, info, etc. if needed
}

function logToFile(filePath, level, messages) {
    const timestamp = new Date().toISOString();
    let logMessage = `${timestamp} [${level}]`;

    // Convert each argument to JSON if it's an object
    messages.forEach(arg => {
        if (typeof arg === 'object') {
            logMessage += ' ' + JSON.stringify(arg);
        } else {
            logMessage += ' ' + arg;
        }
    });

    logMessage += '\n';

    fs.appendFile(filePath, logMessage, (err) => {
        if (err) {
            console.error('Error writing to log file:', err);
        }
    });
}

const projectRootDir = process.argv[2];
const device_uuid = process.argv[3];
let logDir = projectRootDir + "/logs";
var logFilePath = logDir + "/" + device_uuid + ".log";
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir);
}
redirectConsoleToFile(logFilePath);
const context = {
    console: console,
    btoa: btoa,
    atob: atob,
    global: global,
    projectRootDir: projectRootDir,
    URLSearchParams: URLSearchParams,
    fetch: fetch, //fetch is available in nodejs 17+, no need to install external libs
    setTimeout: (callback, delay, ...args) => {
        const wrappedCallback = () => {
            try {
                callback.apply(null, args);
            } catch (error) {
                // Handle the error by exposing it to the main context
                onVmError(error, 'setTimeout');
            }
        };
        return setTimeout(wrappedCallback, delay);
    },
    setInterval: (callback, delay, ...args) => {
        const wrappedCallback = () => {
            try {
                callback.apply(null, args);
            } catch (error) {
                onVmError(error, 'setInterval');
            }
        };
        return setInterval(wrappedCallback, delay);
    },
    clearTimeout: clearTimeout,
    clearInterval: clearInterval,
    WebSocket: WebSocket,
    onWsOpen: onWsOpen,
    onWsClose: onWsClose,
    onWsError: onWsError,
    onExitCalled: onExitCalled,
    onVmError: onVmError,
    require: require
};

vm.createContext(context); // Contextify the object.
var file = projectRootDir + "/engine/Sys.js";
console.log(file);
if (!fs.existsSync(file)) {
    onVmError(new Error(file + ' not exists!'), 'context run vm');
} else {
    var code = fs.readFileSync(file).toString();

    try {
        vm.runInContext(code, context);
    } catch (error) {
        onVmError(error, 'backgroundScriptFiles');
    }
}
function onExitCalled(code, message) {
    console.error('onExitCalled: ' + code + " - " + message);
}

function onWsOpen(params) {
    console.debug('BackgroundJsRunner onWsOpen', params);
    context?.Sys?.debug('BackgroundJsRunner onWsOpen');
}
function onWsClose(e) {
    console.debug('BackgroundJsRunner onWsClose', e);
    context?.Sys?.debug('BackgroundJsRunner onWsOpen');
    process.exit(1);
}
function onWsError(e) {
    console.debug('BackgroundJsRunner onWsError', e);
    process.exit(1);

}

function onVmError(error, from) {
    console.error(JSON.stringify([from, JSON.stringify(error.toString()), error?.stack, JSON.stringify(error)]));
}

process.on('uncaughtException', (error) => {
    console.error('uncaughtException:', error);
    context?.Sys?.error(error.message + ": " + error.toString() + ": " + error?.stack);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection: ', promise, 'reason:', reason);
    context?.Sys?.error('Unhandled Rejection: ' + reason);
});
