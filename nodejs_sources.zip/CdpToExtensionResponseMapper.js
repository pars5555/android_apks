function convert(extensionCommandStr, cdpResponseObject) {
  switch (extensionCommandStr){
      case "chrome.debugger.sendCommand":
          return {id: cdpResponseObject.targetId};
  }
}

module.exports = convert;
