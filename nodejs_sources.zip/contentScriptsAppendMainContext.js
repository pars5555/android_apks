!function () {

    var dl_n = [], dl_d = !1, dl_o = !1;
    function dl_a() {
        if (!dl_d) {
            dl_d = !0;
            for (var dl_t = 0; dl_t < dl_n.length; dl_t++)
                dl_n[dl_t].fn.call(window, dl_n[dl_t].ctx);
            dl_n = [];
        }
    }
    function dl_c() {
        "complete" !== document.readyState && "interactive" !== document.readyState || dl_a();
    }
    function docLoaded(dl_t, dl_e) {
        dl_d ? setTimeout((function () {
            dl_t(dl_e);
        }), 1) : (dl_n.push({fn: dl_t, ctx: dl_e}), "complete" === document.readyState || "interactive" === document.readyState ? setTimeout(dl_a, 1) : dl_o || (document.addEventListener ? (document.addEventListener("DOMContentLoaded", dl_a, !1), window.addEventListener("load", dl_a, !1)) : (document.attachEvent("onreadystatechange", dl_c), window.attachEvent("onload", dl_a)), dl_o = !0));
    }


    var dr_n = [], dr_o = !1, dr_d = !1;
    function dr_a() {
        if (!dr_o) {
            dr_o = !0;
            for (var dr_t = 0; dr_t < dr_n.length; dr_t++)
                dr_n[dr_t].fn.call(window, dr_n[dr_t].ctx);
            dr_n = [];
        }
    }
    function dr_c() {
        "complete" === document.readyState && dr_a();
    }
    function docReady(dr_t, dr_e) {
        dr_o ? setTimeout((function () {
            dr_t(dr_e);
        }), 1) : (dr_n.push({fn: dr_t, ctx: dr_e}), "complete" === document.readyState ? setTimeout(dr_a, 1) : dr_d || (document.addEventListener ? (document.addEventListener("DOMContentLoaded", dr_a, !1), window.addEventListener("load", dr_a, !1)) : (document.attachEvent("onreadystatechange", dr_c), window.attachEvent("onload", dr_a)), dr_d = !0));
    }


    function shExpMatchs(url, shexp) {
        if (typeof shexp === 'string') {
            return shExpMatch(url, shexp);
        }
        for (var i = 0; i < shexp.length; i++) {
            if (shExpMatch(url, shexp[i])) {
                return true;
            }
        }
        return false;
    }

    function shExpMatch(str, shexp) {
        if (typeof str !== 'string' || typeof shexp !== 'string') {
            return false;
        }
        if ((str === '' && shexp === '') || shexp === '*' || shexp === '<all_urls>') {
            return true;
        }
        str = str.toLowerCase();
        shexp = shexp.toLowerCase();
        var index = shexp.indexOf('*');
        if (index === -1) {
            return (str === shexp);
        } else if (index === 0) {
            for (var i = 0; i <= str.length; i++) {
                if (shExpMatch(str.substring(i), shexp.substring(1)))
                    return true;
            }
            return false;
        } else {
            var sub = null,
                    sub2 = null;
            sub = shexp.substring(0, index);
            if (index <= str.length)
                sub2 = str.substring(0, index);
            if (sub !== '' && sub2 !== '' && sub === sub2) {
                return shExpMatch(str.substring(index), shexp.substring(index));
            } else {
                return false;
            }
        }
    }

    "{rep}";

}();

