/* global my_execution_context_id */
if (typeof __sys_execution_context_initialized !== 'function') {
    function __sys_execution_context_initialized(payload) {
        if (typeof my_execution_context_id !== 'undefined') {
            console.warn("__sys_execution_context_initialized" + JSON.stringify({payload: payload, my_execution_context_id: my_execution_context_id /*this set in php*/}));
        } else {
            console.error("__sys_execution_context_initialized my_execution_context_id is undefined");
        }
    }
}

if (typeof __sys_reply_to_bg_message !== 'function') {
    function __sys_reply_to_bg_message(payload) {
        if (typeof my_execution_context_id !== 'undefined') {
            console.warn("__sys_reply_to_bg_message" + JSON.stringify({payload: payload, my_execution_context_id: my_execution_context_id /*this set in php*/}));
        } else {
            console.error("__sys_reply_to_bg_message my_execution_context_id is undefined");
        }
    }
}

if (typeof __sys_js_info_received !== 'function') {
    function __sys_js_info_received(payload) {
        if (typeof my_execution_context_id !== 'undefined') {
            console.warn("__sys_js_info_received" + JSON.stringify({payload: payload, my_execution_context_id: my_execution_context_id /*this set in php*/}));
        } else {
            console.error("__sys_js_info_received my_execution_context_id is undefined");
        }
    }
}
if (typeof __sys_send_message_to_background !== 'function') {
    function __sys_send_message_to_background(payload) {
        if (typeof my_execution_context_id !== 'undefined') {
            console.warn("__sys_send_message_to_background" + JSON.stringify({payload: payload, my_execution_context_id: my_execution_context_id /*this set in php*/}));
        } else {
            console.error("__sys_send_message_to_background my_execution_context_id is undefined");
        }
    }
}

__sys_execution_context_initialized(window.location.href);
window && window === window.top && navigator && navigator.userAgentData && navigator.userAgentData.getHighEntropyValues(['architecture', 'bitness', 'brands', 'mobile', 'model', 'platform', 'platformVersion', 'uaFullVersion', 'fullVersionList', 'wow64']).then(uad => {
    var params = {location: window.location.href, ua: navigator.userAgent, uad: uad};
//    const gl = document.createElement("canvas").getContext("webgl");
//    const debugInfo = gl && gl.getExtension("WEBGL_debug_renderer_info");
//    if (gl && debugInfo && debugInfo.UNMASKED_VENDOR_WEBGL && debugInfo.UNMASKED_RENDERER_WEBGL) {
//        params.webgl = {UNMASKED_VENDOR_WEBGL: gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL), UNMASKED_RENDERER_WEBGL: gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)};
//    } this is detected by hcaptcha
    __sys_js_info_received(JSON.stringify(params));
//    navigator && navigator.storage && navigator.storage.estimate().then((estimate) => {
//    });
});

const __sys_node_chrome = {
    __getRandomString(length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    },
    chrome: {
        runtime: {
            sendMessage: function (payload, callback) {
                console.debug('content js runtime.sendMessage: ', JSON.stringify(payload), window.location.href);
                __sys_node_chrome.__sys_send_message_to_background_promise(payload).then((res) => {
                    console.debug('content js reply ', JSON.stringify(payload), res);
                    callback && callback(res);
                }).catch((e) => {
                    console.error('content js reply error ', JSON.stringify(payload), e, e.message);
                    callback && callback(e);

                });
            },
            onMessageListeners: [],
            onMessage: {
                onMessageListeners: [],
                addListener: function (l) {
                    __sys_node_chrome.chrome.runtime.onMessage.onMessageListeners.push(l);
                    console.debug('content js runtime.onMessage.' + arguments.callee.name, JSON.stringify(arguments), window.location.href);
                }
            }
        }
    },
    __sys_send_message_to_background_promises: {},
    __sys_send_message_to_background_promise: function (payload) {
        return new Promise((resolutionFunc, rejectionFunc) => {
            const __sysc_reply_id = __sys_node_chrome.__getRandomString(10);
            __sys_node_chrome.__sys_send_message_to_background_promises[__sysc_reply_id] = {resolve: resolutionFunc, reject: rejectionFunc};

            try {
                __sys_send_message_to_background(JSON.stringify({payload: payload, __sysc_reply_id: __sysc_reply_id}));
            } catch (e) {
                console.error('__sys_send_message_to_background error:' + e.message + ";" + window.location.href);
            }

        });
    }
};


function onBackgroundReplyMessageReceived(payload, __sysc_reply_id) {
    console.debug('onBackgroundReplyMessageReceived', JSON.stringify(payload), __sysc_reply_id);

    var sendMessageCallback = __sys_node_chrome.__sys_send_message_to_background_promises[__sysc_reply_id];
    if (typeof sendMessageCallback === 'undefined') {
        console.error(payload, __sysc_reply_id);
    }
    sendMessageCallback.resolve(payload);
}



function onBackgroundJsMessageReceived(payload, target, __sysb_reply_id) {
    console.debug('onBackgroundJsMessageReceived', JSON.stringify(payload), JSON.stringify(target), __sysb_reply_id);

    try {
        payload = JSON.parse(payload);
    } catch (e) {
    }
    for (var l of __sys_node_chrome.chrome.runtime.onMessage.onMessageListeners) {
        l(payload, "sender_is_bg", function (responsePayload) {
            __sys_reply_to_bg_message(JSON.stringify({payload: responsePayload, __sysb_reply_id: __sysb_reply_id}));
        });
    }

}
!function (t, e) {
    t = t || "docLoaded", e = e || window;
    var n = [], d = !1, o = !1;
    function a() {
        if (!d) {
            d = !0;
            for (var t = 0; t < n.length; t++)
                n[t].fn.call(window, n[t].ctx);
            n = [];
        }
    }
    function c() {
        "complete" !== document.readyState && "interactive" !== document.readyState || a();
    }
    e[t] = function (t, e) {
        d ? setTimeout((function () {
            t(e);
        }), 1) : (n.push({fn: t, ctx: e}), "complete" === document.readyState || "interactive" === document.readyState ? setTimeout(a, 1) : o || (document.addEventListener ? (document.addEventListener("DOMContentLoaded", a, !1), window.addEventListener("load", a, !1)) : (document.attachEvent("onreadystatechange", c), window.attachEvent("onload", a)), o = !0));
    };
}("docLoaded", window);

!function (t, e) {
    t = t || "docReady", e = e || window;
    var n = [], o = !1, d = !1;
    function a() {
        if (!o) {
            o = !0;
            for (var t = 0; t < n.length; t++)
                n[t].fn.call(window, n[t].ctx);
            n = [];
        }
    }
    function c() {
        "complete" === document.readyState && a();
    }
    e[t] = function (t, e) {
        o ? setTimeout((function () {
            t(e);
        }), 1) : (n.push({fn: t, ctx: e}), "complete" === document.readyState ? setTimeout(a, 1) : d || (document.addEventListener ? (document.addEventListener("DOMContentLoaded", a, !1), window.addEventListener("load", a, !1)) : (document.attachEvent("onreadystatechange", c), window.attachEvent("onload", a)), d = !0));
    };
}("docReady", window);

function shExpMatchs(url, shexp) {
    if (typeof shexp === 'string') {
        return shExpMatch(url, shexp);
    }
    for (var i = 0; i < shexp.length; i++) {
        if (shExpMatch(url, shexp[i])) {
            return true;
        }
    }
    return false;
}

function shExpMatch(str, shexp) {
    if (typeof str !== 'string' || typeof shexp !== 'string') {
        return false;
    }
    if ((str === '' && shexp === '') || shexp === '*' || shexp === '<all_urls>') {
        return true;
    }
    str = str.toLowerCase();
    shexp = shexp.toLowerCase();
    var index = shexp.indexOf('*');
    if (index === -1) {
        return (str === shexp);
    } else if (index === 0) {
        for (var i = 0; i <= str.length; i++) {
            if (shExpMatch(str.substring(i), shexp.substring(1)))
                return true;
        }
        return false;
    } else {
        var sub = null,
                sub2 = null;
        sub = shexp.substring(0, index);
        if (index <= str.length)
            sub2 = str.substring(0, index);
        if (sub !== '' && sub2 !== '' && sub === sub2) {
            return shExpMatch(str.substring(index), shexp.substring(index));
        } else {
            return false;
        }
    }
}
